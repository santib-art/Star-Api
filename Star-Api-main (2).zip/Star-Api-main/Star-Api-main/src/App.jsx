import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, NavLink, useNavigate } from 'react-router-dom';

import Inicio from './components/inicio';
import Coleccion from './components/coleccion';
import Favoritos from './components/favoritos';
import Info from './components/info';
import Usuario from './components/usuario';
import Starwars from './components/starwars';
import './App.css';

function leerSesion() {
  try {
    return JSON.parse(localStorage.getItem('sesionGalactica') || 'null');
  } catch {
    return null;
  }
}

const IconoLogin = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
    <polyline points="10 17 15 12 10 7" />
    <line x1="15" y1="12" x2="3" y2="12" />
  </svg>
);

const IconoLogout = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

function Navegacion() {
  const [sesion, setSesion] = useState(leerSesion);
  const navigate = useNavigate();

  useEffect(() => {
    const actualizarSesion = () => setSesion(leerSesion());
    window.addEventListener('sesion-cambiada', actualizarSesion);
    window.addEventListener('storage', actualizarSesion);
    return () => {
      window.removeEventListener('sesion-cambiada', actualizarSesion);
      window.removeEventListener('storage', actualizarSesion);
    };
  }, []);

  const cerrarSesionRapido = () => {
    localStorage.removeItem('sesionGalactica');
    window.dispatchEvent(new Event('sesion-cambiada'));
    navigate('/usuario');
  };

  return (
    <nav className="c-menu" aria-label="Navegación principal">
      <NavLink to="/" end>Hangar</NavLink>
      <NavLink to="/coleccion">Mi flota</NavLink>
      <NavLink to="/favoritos">Guardadas</NavLink>
      <NavLink to="/info">Archivo</NavLink>
      <NavLink to="/usuario" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
        {!sesion && <IconoLogin />}
        <span>{sesion ? `Perfil (${sesion.nombre})` : 'Perfil · Login'}</span>
      </NavLink>

      {sesion && (
        <button
          type="button"
          onClick={cerrarSesionRapido}
          title="Cerrar sesión"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            background: 'transparent',
            border: '1px solid #8a4b4b',
            color: '#f2a7a7',
            padding: '4px 10px',
            font: 'inherit',
            cursor: 'pointer'
          }}
        >
          <IconoLogout />
          <span>Logout</span>
        </button>
      )}
    </nav>
  );
}

function App() {
  return (
    <Router>
      <Navegacion />
      <Routes>
        <Route path='/' element={<Inicio />} />
        <Route path='/coleccion' element={<Coleccion />} />
        <Route path='/favoritos' element={<Favoritos />} />
        <Route path='/info' element={<Info />} />
        <Route path='/usuario' element={<Usuario />} />
        <Route path='/naves/:id' element={<Starwars />} />
        <Route path='/archivo/:tipo/:id' element={<Starwars />} />
      </Routes>
    </Router>
  );
}

export default App;