import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './style.css';

function leerLista(clave) {
    try {
        const datos = JSON.parse(localStorage.getItem(clave) || '[]');
        return Array.isArray(datos) ? datos : [];
    } catch {
        return [];
    }
}

function leerObjeto(clave) {
    try {
        return JSON.parse(localStorage.getItem(clave) || 'null');
    } catch {
        return null;
    }
}

/* Iconos SVG */
const IconoLogin = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
        <polyline points="10 17 15 12 10 7" />
        <line x1="15" y1="12" x2="3" y2="12" />
    </svg>
);

const IconoLogout = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <polyline points="16 17 21 12 16 7" />
        <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
);

function Usuario() {
    const navesExploradas = leerLista('navesExploradas');
    const navesFavoritas = leerLista('navesFavoritas');

    // Estados de autenticación y CRUD
    const [usuarios, setUsuarios] = useState(() => leerLista('usuariosGalacticos'));
    const [sesionActiva, setSesionActiva] = useState(() => leerObjeto('sesionGalactica'));
    const [vista, setVista] = useState('login'); // 'login' | 'registro' | 'crud'
    const [mensaje, setMensaje] = useState('');

    // Formulario Login
    const [loginForm, setLoginForm] = useState({ correo: '', password: '' });

    // Formulario Registro / Edición CRUD
    const [usuarioForm, setUsuarioForm] = useState({
        id: null,
        nombre: '',
        correo: '',
        password: '',
        rango: 'Piloto Cadete'
    });

    useEffect(() => {
        localStorage.setItem('usuariosGalacticos', JSON.stringify(usuarios));
    }, [usuarios]);

    useEffect(() => {
        if (sesionActiva) {
            localStorage.setItem('sesionGalactica', JSON.stringify(sesionActiva));
        } else {
            localStorage.removeItem('sesionGalactica');
        }
    }, [sesionActiva]);

    const notificar = (texto) => {
        setMensaje(texto);
        setTimeout(() => setMensaje(''), 3500);
    };

    // --- LOGIN ---
    const manejarLogin = (e) => {
        e.preventDefault();
        const encontrado = usuarios.find(
            (u) => u.correo.toLowerCase() === loginForm.correo.toLowerCase() && u.password === loginForm.password
        );
        if (!encontrado) {
            notificar('Credenciales incorrectas o explorador no registrado.');
            return;
        }
        setSesionActiva(encontrado);
        setLoginForm({ correo: '', password: '' });
        notificar(`Acceso concedido. Bienvenido, ${encontrado.nombre}.`);
    };

    // --- LOGOUT ---
    const manejarLogout = () => {
        setSesionActiva(null);
        setVista('login');
        notificar('Sesión cerrada correctamente.');
    };

    // --- REGISTRO (CREATE) ---
    const manejarRegistro = (e) => {
        e.preventDefault();
        if (!usuarioForm.nombre.trim() || !usuarioForm.correo.trim() || !usuarioForm.password.trim()) {
            notificar('Completa todos los campos obligatorios.');
            return;
        }

        const existe = usuarios.some(
            (u) => u.correo.toLowerCase() === usuarioForm.correo.toLowerCase() && u.id !== usuarioForm.id
        );
        if (existe) {
            notificar('Ya existe un explorador con ese correo.');
            return;
        }

        if (usuarioForm.id) {
            // UPDATE (CRUD)
            const actualizados = usuarios.map((u) =>
                u.id === usuarioForm.id ? { ...usuarioForm } : u
            );
            setUsuarios(actualizados);
            if (sesionActiva && sesionActiva.id === usuarioForm.id) {
                setSesionActiva({ ...usuarioForm });
            }
            notificar('Datos del explorador actualizados.');
        } else {
            // CREATE
            const nuevoUsuario = {
                ...usuarioForm,
                id: Date.now()
            };
            setUsuarios([...usuarios, nuevoUsuario]);
            if (!sesionActiva) {
                setSesionActiva(nuevoUsuario);
            }
            notificar('Explorador registrado en la base local.');
        }

        setUsuarioForm({ id: null, nombre: '', correo: '', password: '', rango: 'Piloto Cadete' });
        if (sesionActiva) setVista('crud');
    };

    // --- EDITAR (PREPARAR UPDATE) ---
    const seleccionarParaEditar = (usuario) => {
        setUsuarioForm(usuario);
        setVista('crud');
    };

    // --- ELIMINAR (DELETE) ---
    const eliminarUsuario = (id) => {
        const filtrados = usuarios.filter((u) => u.id !== id);
        setUsuarios(filtrados);
        if (sesionActiva && sesionActiva.id === id) {
            setSesionActiva(null);
            setVista('login');
        }
        notificar('Registro de explorador eliminado.');
    };

    return (
        <main className="perfil-explorador">
            <div className="perfil-cabecera">
                <div>
                    <p className="hangar-etiqueta">REGISTRO LOCAL</p>
                    <h1>{sesionActiva ? sesionActiva.nombre : 'Perfil de explorador'}</h1>
                    <p className="perfil-intro">
                        {sesionActiva
                            ? `Rango: ${sesionActiva.rango} · ${sesionActiva.correo}`
                            : 'Tu actividad de exploración se guarda únicamente en este dispositivo.'}
                    </p>
                </div>

                {/* Botón dinámico de Login / Logout con icono */}
                <div className="perfil-acciones-top">
                    {sesionActiva ? (
                        <button type="button" className="btn-auth btn-logout" onClick={manejarLogout}>
                            <IconoLogout />
                            <span>Cerrar sesión</span>
                        </button>
                    ) : (
                        <button
                            type="button"
                            className="btn-auth btn-login"
                            onClick={() => setVista('login')}
                        >
                            <IconoLogin />
                            <span>Iniciar sesión</span>
                        </button>
                    )}
                </div>
            </div>

            {mensaje && <div className="perfil-alerta">{mensaje}</div>}

            {/* Barra de navegación interna */}
            <nav className="perfil-tabs">
                {!sesionActiva && (
                    <>
                        <button
                            type="button"
                            className={vista === 'login' ? 'activo' : ''}
                            onClick={() => setVista('login')}
                        >
                            Acceso
                        </button>
                        <button
                            type="button"
                            className={vista === 'registro' ? 'activo' : ''}
                            onClick={() => {
                                setUsuarioForm({ id: null, nombre: '', correo: '', password: '', rango: 'Piloto Cadete' });
                                setVista('registro');
                            }}
                        >
                            Registro
                        </button>
                    </>
                )}
                <button
                    type="button"
                    className={vista === 'crud' ? 'activo' : ''}
                    onClick={() => setVista('crud')}
                >
                    Gestión de Usuarios ({usuarios.length})
                </button>
            </nav>

            {/* VISTA LOGIN */}
            {!sesionActiva && vista === 'login' && (
                <section className="panel-usuario">
                    <h2>Iniciar sesión</h2>
                    <form onSubmit={manejarLogin} className="form-usuario">
                        <label>
                            Correo galáctico
                            <input
                                type="email"
                                required
                                placeholder="piloto@alianza.org"
                                value={loginForm.correo}
                                onChange={(e) => setLoginForm({ ...loginForm, correo: e.target.value })}
                            />
                        </label>
                        <label>
                            Código de acceso
                            <input
                                type="password"
                                required
                                placeholder="••••••••"
                                value={loginForm.password}
                                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                            />
                        </label>
                        <button type="submit" className="btn-auth btn-login">
                            <IconoLogin />
                            <span>Entrar al sistema</span>
                        </button>
                    </form>
                </section>
            )}

            {/* VISTA REGISTRO */}
            {!sesionActiva && vista === 'registro' && (
                <section className="panel-usuario">
                    <h2>Nuevo registro de explorador</h2>
                    <form onSubmit={manejarRegistro} className="form-usuario">
                        <label>
                            Nombre o indicativo
                            <input
                                type="text"
                                required
                                placeholder="Ej. Wedge Antilles"
                                value={usuarioForm.nombre}
                                onChange={(e) => setUsuarioForm({ ...usuarioForm, nombre: e.target.value })}
                            />
                        </label>
                        <label>
                            Correo galáctico
                            <input
                                type="email"
                                required
                                placeholder="wedge@escuadronrojo.org"
                                value={usuarioForm.correo}
                                onChange={(e) => setUsuarioForm({ ...usuarioForm, correo: e.target.value })}
                            />
                        </label>
                        <label>
                            Rango
                            <select
                                value={usuarioForm.rango}
                                onChange={(e) => setUsuarioForm({ ...usuarioForm, rango: e.target.value })}
                            >
                                <option value="Piloto Cadete">Piloto Cadete</option>
                                <option value="Comandante de Flota">Comandante de Flota</option>
                                <option value="Cazarrecompensas">Cazarrecompensas</option>
                                <option value="Ingeniero Naval">Ingeniero Naval</option>
                            </select>
                        </label>
                        <label>
                            Código de acceso
                            <input
                                type="password"
                                required
                                placeholder="Crea una contraseña"
                                value={usuarioForm.password}
                                onChange={(e) => setUsuarioForm({ ...usuarioForm, password: e.target.value })}
                            />
                        </label>
                        <button type="submit" className="btn-auth btn-login">
                            Registrar explorador
                        </button>
                    </form>
                </section>
            )}

            {/* VISTA CRUD DE USUARIOS */}
            {(vista === 'crud' || sesionActiva) && (
                <section className="panel-usuario">
                    <h2>{usuarioForm.id ? 'Editar explorador' : 'CRUD · Directorio de exploradores'}</h2>

                    <form onSubmit={manejarRegistro} className="form-usuario form-grid">
                        <input
                            type="text"
                            required
                            placeholder="Nombre"
                            value={usuarioForm.nombre}
                            onChange={(e) => setUsuarioForm({ ...usuarioForm, nombre: e.target.value })}
                        />
                        <input
                            type="email"
                            required
                            placeholder="Correo"
                            value={usuarioForm.correo}
                            onChange={(e) => setUsuarioForm({ ...usuarioForm, correo: e.target.value })}
                        />
                        <select
                            value={usuarioForm.rango}
                            onChange={(e) => setUsuarioForm({ ...usuarioForm, rango: e.target.value })}
                        >
                            <option value="Piloto Cadete">Piloto Cadete</option>
                            <option value="Comandante de Flota">Comandante de Flota</option>
                            <option value="Cazarrecompensas">Cazarrecompensas</option>
                            <option value="Ingeniero Naval">Ingeniero Naval</option>
                        </select>
                        <input
                            type="password"
                            required
                            placeholder="Contraseña"
                            value={usuarioForm.password}
                            onChange={(e) => setUsuarioForm({ ...usuarioForm, password: e.target.value })}
                        />
                        <div className="form-crud-botones">
                            <button type="submit" className="btn-auth btn-login">
                                {usuarioForm.id ? 'Guardar cambios' : 'Crear usuario'}
                            </button>
                            {usuarioForm.id && (
                                <button
                                    type="button"
                                    className="btn-secundario"
                                    onClick={() =>
                                        setUsuarioForm({ id: null, nombre: '', correo: '', password: '', rango: 'Piloto Cadete' })
                                    }
                                >
                                    Cancelar
                                </button>
                            )}
                        </div>
                    </form>

                    {usuarios.length === 0 ? (
                        <p className="perfil-intro">No hay exploradores registrados aún.</p>
                    ) : (
                        <div className="tabla-crud-contenedor">
                            <table className="tabla-crud">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Correo</th>
                                        <th>Rango</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {usuarios.map((u) => (
                                        <tr key={u.id} className={sesionActiva?.id === u.id ? 'fila-activa' : ''}>
                                            <td>
                                                {u.nombre} {sesionActiva?.id === u.id && <small>(Tú)</small>}
                                            </td>
                                            <td>{u.correo}</td>
                                            <td>{u.rango}</td>
                                            <td className="crud-acciones">
                                                <button
                                                    type="button"
                                                    className="btn-accion"
                                                    onClick={() => seleccionarParaEditar(u)}
                                                >
                                                    Editar
                                                </button>
                                                <button
                                                    type="button"
                                                    className="btn-accion btn-eliminar"
                                                    onClick={() => eliminarUsuario(u.id)}
                                                >
                                                    Eliminar
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </section>
            )}

            {/* Estadísticas originales */}
            <section className="perfil-estadisticas">
                <Link to="/coleccion">
                    <strong>{navesExploradas.length}</strong>
                    <span>Naves exploradas</span>
                    <small>Abrir mi flota ↗</small>
                </Link>
                <Link to="/favoritos">
                    <strong>{navesFavoritas.length}</strong>
                    <span>Naves guardadas</span>
                    <small>Ver favoritas ↗</small>
                </Link>
            </section>
        </main>
    );
}

export default Usuario;